package com.assignment06;

public class InsufficientBalanceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientBalanceException() {
		super("Insufficient balance in the account!!");
		// TODO Auto-generated constructor stub
	}

}
