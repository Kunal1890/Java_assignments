package day3;

public class Static {
	static int StudntCount;
    static int getstudentCount() {
		return StudntCount;
    	
    }

}
