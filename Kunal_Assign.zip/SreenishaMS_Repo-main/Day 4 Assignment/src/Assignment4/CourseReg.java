package Assignment4;

public class CourseReg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DayScholar dayscholar = new DayScholar(1001, 'D', "Serena", 12000, "NYC");
		dayscholar.displayDetails();

	}

}
