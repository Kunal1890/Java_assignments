package com.assignment9;

public class StudentMain {
	
	public static void main(String[] args) {
		
		Student st1=new Student('H',"John");
		
		st1.displayDetails(); 
	 
		Student st2=new Student('D',"Jack");
		st2.displayDetails(); 
		
	}

}
