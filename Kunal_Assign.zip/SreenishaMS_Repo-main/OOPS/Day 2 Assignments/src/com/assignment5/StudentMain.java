package com.assignment5;

public class StudentMain {
public static void main(String[] args) {
	Student st1=new Student();
	System.out.println("Student Details :\nStudent Id: "+st1.getStudentId()+"\nStudent Type: "+st1.getStudentType());
}
}
