package com.pack;

public class Assignment8 {
public static void main(String[] args) {
	int intVal=100;
	byte byteVal=(byte)intVal;
	final byte  max=127;
	final byte  min=-128;
	byte sum=max+min;
	
	System.out.println("Sum= "+sum);
}
}
