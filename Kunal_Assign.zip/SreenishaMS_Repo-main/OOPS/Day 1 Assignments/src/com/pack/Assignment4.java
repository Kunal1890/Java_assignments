package com.pack;

public class Assignment4 {
public static void main(String[] args) {
	System.out.println("Hello world!! \nWelcome to Java!!");
}
}
