package com.pack;

public class Assignment5 {
public static void main(String[] args) {
	 int a=7;
	 float b=7.8f;
	 double c=7.89;
	 boolean d=true;
	 System.out.println("Local Variable \nInteger: "+a+"\nFloat: "+b+"\nDouble: "+c+"\nBoolean: "+d);
	 
	
}
}
