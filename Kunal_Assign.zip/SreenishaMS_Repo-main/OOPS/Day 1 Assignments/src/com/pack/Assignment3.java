package com.pack;

public class Assignment3 {
public static void main(String[] args) {
	System.out.println("Across\r\n"
			+ "\r\n"
			+ "1.STATE\r\n"
			+ "2.CLASS\r\n"
			+ "3.IDENTITY\r\n"
			+ "4.ENCAPSULATION\r\n"
			+ "5.OBJECT\r\n"
			+ "\r\n"
			+ "Down\r\n"
			+ "\r\n"
			+ "6.BEHAVIOUR\r\n"
			+ "7.INHERITANCE\r\n"
			+ "8.ABSTRACTION \r\n"
			+ "9.POLYMORPHISM\r\n"
			+ "\r\n"
			+ "");
}
}
