package registrationpack;

public class Registration {

	public static void main(String[] args) {
		DayScholar ds=new DayScholar();
		ds.setStudentId(1001);
		ds.setStudentType('D');
		ds.setStudentName("Dinil");
		ds.getDetails();
	}
}
