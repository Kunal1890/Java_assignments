package Assignment3;

public interface InterOne {

	int varOne=0;
	int varTwo=100;
	void methodOne();
	void methodtwo();
	
}
