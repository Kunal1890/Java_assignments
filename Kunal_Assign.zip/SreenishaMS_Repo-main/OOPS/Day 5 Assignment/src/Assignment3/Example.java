package Assignment3;

public class Example implements InterOne {

	@Override
	public void methodOne() {
		int varTwo=100;
		// TODO Auto-generated method stub
		varTwo=varTwo+10;
		System.out.println("Value of varTwo: "+varTwo);
		System.out.println("Good Morning");
	}

	@Override
	public void methodtwo() {
		// TODO Auto-generated method stub
		System.out.println("Good Afternoon");

	}

}
