package Assignment3;

public class DemoInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example obj=new Example();
		obj.methodOne();
		obj.methodtwo();
	}

}
